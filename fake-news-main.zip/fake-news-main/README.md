# fake news
chrome extension to detect fake news using ML predictions
